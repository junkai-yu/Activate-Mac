# Activate Mac

## A Boring Widget for macOS

## Works With Ubersicht

![Alt text](screenshot.png)
